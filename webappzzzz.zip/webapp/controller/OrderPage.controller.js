sap.ui.define(
    [
        "sap/ui/model/json/JSONModel",
        "sap/project/controller/BaseController",
        "sap/f/library",
        "sap/m/Dialog",
        "sap/m/Button",
        "sap/m/Label",
        "sap/m/MessageToast",
        "sap/m/Text",
        "sap/m/TextArea",
    ],
    function (
        JSONModel,
        BaseController,
        fioriLibrary,
        Dialog,
        Button,
        Label,
        MessageToast,
        Text,
        TextArea
    ) {
        "use strict";
        var DialogType = fioriLibrary.DialogType;
        var ButtonType = fioriLibrary.ButtonType;

        return BaseController.extend("sap.project.controller.OrderPage", {
            onInit: async function () {
                var oLocalStorage = JSON.parse(
                    localStorage.getItem("ordersLocal")
                );
                this.oView = this.getView();
                var oOrderModel = new JSONModel(oLocalStorage);

                await this.getView().setModel(oOrderModel, "oOrderModel");

                this.oOwnerComponent = this.getOwnerComponent();
                this.oRouter = this.oOwnerComponent.getRouter();
                this.oRouter.attachRouteMatched(this.onRouteMatched, this);
            },
            onRouteMatched: function (oEvent) {
                var oLocalStorage = JSON.parse(
                    localStorage.getItem("ordersLocal")
                );
                console.log("LocalStorage", oLocalStorage);
                var oOrderModel = new JSONModel(oLocalStorage);

                this.getView().setModel(oOrderModel, "oOrderModel");

                this.getView().getModel().refresh();
            },
            onApproveDialogPress: function (id) {
                if (!this.oApproveDialog) {
                    this.oApproveDialog = new Dialog({
                        title: "Confirm",
                        content: new Text({
                            text: "Do you want to submit this order?",
                        }),
                        beginButton: new Button({
                            text: "Submit",
                            press: function () {
                                console.log("id of status", id);
                                this.oApproveDialog.close();
                            }.bind(this),
                        }),
                        endButton: new Button({
                            text: "Cancel",
                            press: function () {
                                this.oApproveDialog.close();
                            }.bind(this),
                        }),
                    });
                }

                this.oApproveDialog.open();
            },

            onNewPressed(oEvent) {
                console.log("new Button");
                //var oFCL = this.oView.getParent().getParent();
                var input = this.byId("app_input_orderno");
                console.log("input", input);
                this.oRouter.navTo("detail", {
                    layout: fioriLibrary.LayoutType.TwoColumnsBeginExpanded,
                    orderid: "create",
                });
            },
            onItemSelected(oEvent) {
                let oData = oEvent.getParameter("rowContext").getObject();

                console.log("sadasd", oData);

                if (oData.status) {
                    MessageToast.show("Order already delivered");
                } else {
                    this.setData(oData);

                    var productPath = oEvent.getSource();

                    // product = productPath.split("/").slice(-1).pop();
                    console.log("productPath", productPath);

                    this.oRouter.navTo("detail", {
                        layout: fioriLibrary.LayoutType.TwoColumnsBeginExpanded,
                        orderid: oData.orderid,
                    });
                }
            },

            onDeleteButtonPressed: function (id) {
                if (!this.oApproveDialog) {
                    this.oApproveDialog = new Dialog({
                        title: "Delete Order",
                        content: new Text({
                            text: "Do you want to delete this order?",
                        }),
                        beginButton: new Button({
                            text: "Yes",
                            press: function () {
                                let oLocalStorage = JSON.parse(
                                    localStorage.getItem("ordersLocal")
                                );
                                console.log(oLocalStorage);
                                var orderData = this.getView()
                                    .getModel("oOrderModel")
                                    .getData().orderList;

                                let filterdData =
                                    oLocalStorage.orderList.filter((item) => {
                                        return item.orderid != id;
                                    });
                                console.log("filterdData", filterdData);
                                localStorage.setItem(
                                    "ordersLocal",
                                    JSON.stringify({ orderList: filterdData })
                                );
                                let oData = new JSONModel({
                                    orderList: filterdData,
                                });
                                this.getView().setModel(oData, "oOrderModel");
                                MessageToast.show("Order Deleted");
                                this.oApproveDialog.close();
                            }.bind(this),
                        }),
                        endButton: new Button({
                            text: "No",
                            press: function () {
                                this.oApproveDialog.close();
                            }.bind(this),
                        }),
                    });
                }

                this.oApproveDialog.open();
            },
        });
    }
);
