sap.ui.define(
    [
        "sap/base/Log",
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/core/format/DateFormat",
        "sap/m/ToolbarSpacer",
        "sap/ui/thirdparty/jquery",
        "sap/m/MessageToast",
        "sap/project/controller/BaseController",
        "sap/f/library",
    ],
    function (
        Log,
        Controller,
        JSONModel,
        Filter,
        FilterOperator,
        DateFormat,
        ToolbarSpacer,
        jquery,
        MessageToast,
        BaseController,
        fioriLibrary
    ) {
        "use strict";

        return BaseController.extend("sap.project.controller.OrderPage", {
            onInit: async function () {
                var oLocalStorage = JSON.parse(
                    localStorage.getItem("ordersLocal")
                );
                this.oView = this.getView();
                var oOrderModel = new JSONModel(oLocalStorage);

                await this.getView().setModel(oOrderModel, "oOrderModel");

                this.oOwnerComponent = this.getOwnerComponent();
                this.oRouter = this.oOwnerComponent.getRouter();
                this.oRouter.attachRouteMatched(this.onRouteMatched, this);
            },
            onRouteMatched: function (oEvent) {
                var oLocalStorage = JSON.parse(
                    localStorage.getItem("ordersLocal")
                );
                console.log("LocalStorage", oLocalStorage);
                var oOrderModel = new JSONModel(oLocalStorage);

                this.getView().setModel(oOrderModel, "oOrderModel");

                this.getView().getModel().refresh();
            },

            onNewPressed(oEvent) {
                console.log("new Button");
                //var oFCL = this.oView.getParent().getParent();
                var input = this.byId("app_input_orderno");
                console.log("input", input);
                this.oRouter.navTo("detail", {
                    layout: fioriLibrary.LayoutType.TwoColumnsBeginExpanded,
                    orderid: "create",
                });
            },
            onItemSelected(oEvent) {
                let oData = oEvent.getParameter("rowContext").getObject();

                console.log("sadasd", oData);

                if (oData.status) {
                    MessageToast.show("Order already delivered");
                } else {
                    this.setData(oData);

                    var productPath = oEvent.getSource();

                    // product = productPath.split("/").slice(-1).pop();
                    console.log("productPath", productPath);

                    this.oRouter.navTo("detail", {
                        layout: fioriLibrary.LayoutType.TwoColumnsBeginExpanded,
                        orderid: oData.orderid,
                    });
                }
            },

            onDeleteButtonPressed: function (id) {
                var orderData = this.getView()
                    .getModel("oOrderModel")
                    .getData().orderList;

                let filterdData = orderData.filter((item) => {
                    return item.orderid != id;
                });
                let oData = new JSONModel({
                    orderList: filterdData,
                });
                this.getView().setModel(oData, "oOrderModel");
            },
        });
    }
);
