sap.ui.define(
    [
        "sap/base/Log",
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/core/format/DateFormat",
        "sap/m/ToolbarSpacer",
        "sap/ui/thirdparty/jquery",
        "sap/f/library",
        "sap/m/MessageToast",
    ],
    function (
        Log,
        Controller,
        JSONModel,
        Filter,
        FilterOperator,
        DateFormat,
        ToolbarSpacer,
        jQuery,
        fioriLibrary,
        MessageToast
    ) {
        "use strict";

        return Controller.extend("sap.project.controller.OrderPage", {
            onInit: function () {
                this.oView = this.getView();

                // set explored app's demo model on this sample
                var oJSONModel = this.initSampleDataModel();
                console.log("oJSONModel", oJSONModel);

                this.oView.setModel(oJSONModel);
                // console.log("oView", oView);

                this.oView.setModel(
                    new JSONModel({
                        availabilityFilterOn: false,
                        cellFilterOn: false,
                    }),
                    "ui"
                );
                console.log(
                    "Pattern Matched",
                    this.getOwnerComponent().getRouter().getRoute("OrderPage")
                );
            },
            _onPatternMatched: function (oEvent) {
                let oNewCustomerContext = this.getView().getModel();

                this.getView().getModel("OrderPage");
            },
            onNewPressed(oEvent) {
                console.log("new Button");
                var oFCL = this.byId("flexibleColumnLayout");
                console.log("oFCL", oFCL);
                oFCL.setLayout(fioriLibrary.LayoutType.TwoColumnsBeginExpanded);
            },

            initSampleDataModel: function () {
                var oModel = new JSONModel();
                console.log("oModel init", oModel);

                jQuery.ajax(sap.ui.require.toUrl("sap/project/orders.json"), {
                    dataType: "json",
                    success: function (oData) {
                        oModel.setData(oData);
                    },
                    error: function () {
                        Log.error("failed to load json");
                    },
                });

                return oModel;
            },
            onItemSelected(oEvent) {
                let oData = oEvent.getParameter("rowContext").getObject();
                if (oData.status === "yes") {
                    MessageToast.show("Order already delivered");
                } else {
                    var oFCL = this.byId("flexibleColumnLayout");
                    oFCL.setLayout(
                        fioriLibrary.LayoutType.TwoColumnsBeginExpanded
                    );
                }
            },
        });
    }
);
