sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/f/library",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Fragment",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/core/Popup",
    ],
    function (
        Controller,
        fioriLibrary,
        JSONModel,
        Fragment,
        Filter,
        FilterOperator,
        Popup
    ) {
        "use strict";

        return Controller.extend("sap.project.controller.Detail", {
            onInit: function () {
                this.oView = this.getView();
                var oModel = new JSONModel(
                    sap.ui.require.toUrl("sap/project/helper.json")
                );
                console.log("oModel", oModel);
                this.getView().setModel(oModel);
            },

            onCancelPressed() {
                var oFCL = this.oView.getParent().getParent();
                console.log("oFCL", oFCL);
                oFCL.setLayout(fioriLibrary.LayoutType.OneColumn);
            },
            handleValueHelp: function () {
                var oView = this.getView();
                // console.log("oView", oView);
                if (!this._pValueHelpDialogs) {
                    this._pValueHelpDialogs = Fragment.load({
                        id: oView.getId(),
                        name: "sap.project.view.fragment.ValueHelp",
                        controller: this,
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }
                this._pValueHelpDialogs.then(
                    function (oValueHelpDialog) {
                        oValueHelpDialog.open();
                        this._configValueHelpDialog();
                    }.bind(this)
                );

                // if (!this._pValueHelpDialog) {
                //     this._pValueHelpDialog = Fragment.load({
                //         id: oView.getId(),
                //         name: "sap.project.view.ValueHelp",
                //         controller: this,
                //     }).then(function (oValueHelpDialog) {
                //         oView.addDependent(oValueHelpDialog);
                //         return oValueHelpDialog;
                //     });
                // }
            },
            onCloseDialog(oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem"),
                    oInput = this.byId("app_input_customername");
                console.log("oSelectedItem", oSelectedItem);

                if (!oSelectedItem) {
                    oInput.resetProperty("value");
                    return;
                }

                oInput.setValue(oSelectedItem.getCells()[1].getTitle());
            },
            _configValueHelpDialog: function () {
                var sInputValue = this.byId(
                        "app_input_customername"
                    ).getValue(),
                    oModel = this.getView().getModel(),
                    aProducts = oModel.getProperty("/helpList");
                console.log("sInputValue", aProducts);

                aProducts.forEach(function (oProduct) {
                    oProduct.selected = oProduct.customerName === sInputValue;
                });
                console.log("sInputValue", sInputValue);
                oModel.setProperty("/helpList", aProducts);
                //console.log("sInputValue", selected);
            },
            handleSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");

                var oFilter = new Filter(
                    "customerName",
                    FilterOperator.Contains,
                    sValue
                );
                var oBinding = oEvent.getSource().getBinding("items");
                oBinding.filter([oFilter]);
            },
        });
    }
);
